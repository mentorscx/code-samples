export default {
  providers: [
    {
      domain: "https://actual-glider-21.clerk.accounts.dev",
      applicationID: "convex",
    }
  ]
}