import Loader from "@/app/components/Loader";

const Loading = () => {
  return ( 
    <Loader />
   );
}
 
export default Loading;