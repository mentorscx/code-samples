"use client";

import { CrispChat } from "@/components/crisp-chat";

export const CrispProvider = () => {
  return <CrispChat />
};
