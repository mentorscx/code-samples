import Header from "@/components/Header";

const Search = () => {
  return ( 
    <>
      <Header label="Search" />
    </>
   );
}
 
export default Search;