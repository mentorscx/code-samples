export default {
  providers: [
    {
      domain: "https://just-mastodon-0.clerk.accounts.dev",
      applicationID: "convex",
    },
  ]
};
